import { useState } from 'react';
import './imgList.scss';

function ImgList() {	

	const Items = ( { menu, choice, change } ) => {
		const same = choice === menu.txt || choice === '';
		
		return (
				<button					
						className= { same ?  'active' : '' }
						onClick={ () => { change( menu.txt ); } }
				>{ menu.txt }</button>
		);
	};

	const [ active, setActive ] = useState( menus[0].txt );
	let portfolio = portList.map ( ( i , j )  => 	
		<section key= { j } className={ i.class1 }>
			<img src= { i.sr } alt={ i.al } />
			<div>
				<h4>{ i.al }</h4>
				<a href={ i.hre } className= { i.class2 }>favorite</a>
				<a href={ i.hre } className= { i.class2 }>search</a>
			</div>
		</section>
	);
	
	if ( active === 'Web Design' )
		portfolio = portfolio.filter( ( i ) => i.props.className === 'web');
	else if ( active === 'Development' )
		portfolio = portfolio.filter( ( i ) => i.props.className === 'de');
	else if ( active === 'Marketing' )
		portfolio = portfolio.filter( ( i ) => i.props.className === 'ma');

	//console.log(portfolio);
	return (
			<div>
				<section id="layout">
					<h1>My Portfolio</h1>
					<p>I love what I do. I take great pride in what I do.</p>
					<hr />
					<nav>
						{ menus.map( ( i, j ) => (
								<Items key= { j } menu= { i } choice= { active } change= { setActive }  />
						)) }
					</nav>
					<div id="samples">
						{ portfolio }
					</div>
				</section>
			</div>
	);
};

const menus= [
			{	id: 1, txt: 'ALL' },
			{ id:	2, txt: 'Web Design' },
			{ id:	3, txt: 'Development' },
			{ id:	4, txt: 'Marketing' }
];
		
const items= [ //eslint-disable-line no-unused-vars
			{ id:	1, sr: './images/logo.png', al: 'sample image' },
			{ id:	2, sr: './images/logo.png', al: 'sample image' },
			{ id:	3, sr: './images/logo.png', al: 'sample image' },
			{ id:	4, sr: './images/logo.png', al: 'sample image' },
			{ id:	5, sr: './images/logo.png', al: 'sample image' },
			{ id:	6, sr: './images/logo.png', al: 'sample image' },
			{ id:	7, sr: './images/logo.png', al: 'sample image' },
			{ id:	8, sr: './images/logo.png', al: 'sample image' },
			{ id: 9, sr: './images/logo.png', al: 'sample image' }
];
		
const portList= [ 
			{
				id: 1,
				sr:	'./images/sample01.jpg',
				al: 'WEB DESIGN',
				hre: '#',
				class1: 'web',
				class2: 'material-symbols-outlined'
			},{
				id:	2,
				sr: './images/sample02.jpg',
				al: 'DEVELOPMENT',
				hre: '#',
				class1: 'de',
				class2: 'material-symbols-outlined'
			},{
				id:	3,
				sr:	'./images/sample03.jpg',
				al: 'DEVELOPMENT',
				hre: '#',
				class1: 'de',
				class2: 'material-symbols-outlined'
			},{
				id:	4,
				sr:	'./images/sample04.jpg',
				al: 'WEB DESIGN',
				hre: '#',
				class1: 'web',
				class2: 'material-symbols-outlined'
			},{
				id:	5,
				sr:	'./images/sample05.jpg',
				al: 'MARKETING',
				hre: '#',
				class1: 'ma',
				class2: 'material-symbols-outlined'
			},{
				id:	6,
				sr:	'./images/sample06.jpg',
				al: 'WEB DESIGN',
				hre: '#',
				class1: 'web',
				class2: 'material-symbols-outlined'
			},{
				id:	7,
				sr:	'./images/sample07.jpg',
				al: 'WEB DESIGN',
				hre: '#',
				class1: 'web',
				class2: 'material-symbols-outlined'
			},{
				id:	8,
				sr:	'./images/sample08.jpg',
				al: 'DEVELOPMENT',
				hre: '#',
				class1: 'de',
				class2: 'material-symbols-outlined'
			},{
				id:	9,
				sr:	'./images/sample09.jpg',
				al: 'MARKETING',
				hre: '#',
				class1: 'ma',
				class2: 'material-symbols-outlined'
			}
];

export default ImgList;