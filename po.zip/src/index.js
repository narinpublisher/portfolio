import React from 'react';
import ReactDOM from 'react-dom/client';
import './imgList.scss';

function ImgList () {
	const menu= [
		{
			id:	1,
			txt:'ALL'
		},
		{
			id:	2,
			txt:'Web Design'
		},
		{
			id:	3,
			txt:'Development'
		},
		{
			id:	4,
			txt:'Marketing'
		}
	];
	const items= [
		{
			id:	1,
			sr:	'./images/logo.png'
		},
		{
			id:	2,
			sr:	'./images/logo.png'
		},
		{
			id:	3,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	4,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	5,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	6,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	7,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	8,
			sr:	'./images/logo.png',
			al: 'sample image'
		},
		{
			id:	9,
			sr:	'./images/logo.png',
			al: 'sample image'
		}
	];
	const portList= [
		{
			id:	1,
			sr:	'./images/sample01.jpg',
			al: 'WEB DESIGN',
			hre: '#',
			class1: 'web',
			class2: 'material-symbols-outlined'
		},
		{
			id:	2,
			sr:	'./images/sample02.jpg',
			al: 'DEVELOPMENT',
			hre: '#',
			class1: 'de',
			class2: 'material-symbols-outlined'
		},
		{
			id:	3,
			sr:	'./images/sample03.jpg',
			al: 'DEVELOPMENT',
			hre: '#',
			class1: 'de',
			class2: 'material-symbols-outlined'
		},
		{
			id:	4,
			sr:	'./images/sample04.jpg',
			al: 'WEB DESIGN',
			hre: '#',
			class1: 'web',
			class2: 'material-symbols-outlined'
		},
		{
			id:	5,
			sr:	'./images/sample05.jpg',
			al: 'MARKETING',
			hre: '#',
			class1: 'ma',
			class2: 'material-symbols-outlined'
		},
		{
			id:	6,
			sr:	'./images/sample06.jpg',
			al: 'WEB DESIGN',
			hre: '#',
			class1: 'web',
			class2: 'material-symbols-outlined'
		},
		{
			id:	7,
			sr:	'./images/sample07.jpg',
			al: 'WEB DESIGN',
			hre: '#',
			class1: 'web',
			class2: 'material-symbols-outlined'
		},
		{
			id:	8,
			sr:	'./images/sample08.jpg',
			al: 'DEVELOPMENT',
			hre: '#',
			class1: 'de',
			class2: 'material-symbols-outlined'
		},
		{
			id:	9,
			sr:	'./images/sample09.jpg',
			al: 'MARKETING',
			hre: '#',
			class1: 'ma',
			class2: 'material-symbols-outlined'
		}
	];
	
	return (
			<div>
				<section id="layout">
					<h1>My Portfolio</h1>
					<p>I love what I do. I take great pride in what I do.</p>
					<hr />
					<nav>
						{ menu.map (  i  => 	<button type='button' key= { i.id }>{ i.txt }</button>	)}
					</nav>
					<div id="samples">
						{ portList.map ( i  => 
							<section key= { i.id } class={i.class1}>
								<img src= { i.sr } alt={ i.al } />
								<div>
									<h4>{ i.al }</h4>
									<a href={ i.hre} class={ i.class2 }>favorite</a>
									<a href={ i.hre} class={ i.class2 }>search</a>
								</div>
							</section>
						)}
					</div>
				</section>
			</div>
	);
};

const song = ReactDOM.createRoot ( document.getElementById('root') );
song.render ( <ImgList /> );