import ReactDOM from 'react-dom/client';
import MyPort from './myport.js';

const song = ReactDOM.createRoot ( document.getElementById('root') );
song.render ( <MyPort /> );
