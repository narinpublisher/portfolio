import { useState } from 'react';
import ReactDOM from 'react-dom/client';
import './imgList.scss';


function ImgList() {
	const menus= [
			{	id:	1, txt: 'ALL' },
			{ id:	2, txt: 'Web Design' },
			{ id:	3, txt: 'Development' },
			{ id:	4, txt: 'Marketing' }
	];
		
	const items= [ //eslint-disable-line no-unused-vars
			{ id:	1, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	2, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	3, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	4, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	5, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	6, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	7, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	8, sr:	'./images/logo.png', al: 'sample image' },
			{ id:	9, sr:	'./images/logo.png', al: 'sample image' }
	];
		
	const portList= [ 
			{
				id:	1,
				class1: 'web',
				class11: '',
				sr:	'./images/sample01.jpg',
				al: 'WEB DESIGN',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	2,
				class1: 'de',
				class11: '',
				sr:	'./images/sample02.jpg',
				al: 'DEVELOPMENT',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	3,
				class1: 'de',
				class11: '',
				sr:	'./images/sample03.jpg',
				al: 'DEVELOPMENT',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	4,
				class1: 'web',
				class11: '',
				sr:	'./images/sample04.jpg',
				al: 'WEB DESIGN',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	5,
				class1: 'ma',
				class11: '',
				sr:	'./images/sample05.jpg',
				al: 'MARKETING',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	6,
				class1: 'web',
				class11: '',
				sr:	'./images/sample06.jpg',
				al: 'WEB DESIGN',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	7,
				class1: 'web',
				class11: '',
				sr:	'./images/sample07.jpg',
				al: 'WEB DESIGN',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	8,
				class1: 'de',
				class11: '',
				sr:	'./images/sample08.jpg',
				al: 'DEVELOPMENT',
				hre: '#',				
				class2: 'material-symbols-outlined'
			},
			{
				id:	9,
				class1: 'ma',
				class11: '',
				sr:	'./images/sample09.jpg',
				al: 'MARKETING',
				hre: '#',				
				class2: 'material-symbols-outlined'
			}
	];

	//Navigation Menu
	const Items = ( { menu, choice1, change1 } ) => {
		
		const same1 = choice1 === menu.txt || choice1 === '';
		let ccc;//eslint-disable-line no-unused-vars
		return (
				<button					
							className= { same1 ?  'active' : '' }
							onClick={ () => { change1( menu.txt );setMe( menu.txt ) } } 
				>{ menu.txt }</button>
		);	
	};
	
	const Portfolio = ( { port, choice2, change2 } ) => {		
		
		const same2 = choice2 === port || choice2 === '';//eslint-disable-line no-unused-vars, no-unreachable
			
		return (
			<>
						
				<section  className= {port.class1}
				
				
				{  me === 'ALL' ? port.class1+=" show" : ''  }
				{  me === 'Web Design' ? port.class1 = me  : ''  }
				{  me === 'Development' ? port.class1 = me  : ''  }
				{  me === 'Marketing' ? port.class1 = me  : '' }			
				
				
				>
						<img src= { port.sr } alt={ port.al } />
						<div>
									<h4>{ port.al }</h4>
									<a href={ port.hre } className= { port.class2 }>favorite</a>
									<a href={ port.hre } className= { port.class2 }>search</a>
						</div>
				</section>
			</>
		);
		
	};

	const [ active, setActive ] = useState( menus[0].txt );//menu active
	const [ me, setMe ] = useState();//portfolio show
	
	return (
			
			<div>			
				<section id="layout">					
					<h1>My Portfolio</h1>
					<p>I love what I do. I take great pride in what I do.</p>
					<hr />
					<nav>
						{ menus.map( ( i, j ) => (
								<Items key= { j } menu= { i } choice1= { active } change1= { setActive }  />
						)) }
					</nav>
					<div id="samples">					
						{ portList.map ( ( i , j )  => (
								<Portfolio key= { j } port= { i } choice2={ me } change2= { setMe }  />
								)
							)
						}					
					</div>
				</section>				
			</div>
	);	
};


const song = ReactDOM.createRoot ( document.getElementById('root') );
song.render ( <ImgList /> );