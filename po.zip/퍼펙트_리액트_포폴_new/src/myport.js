import { useState, memo } from 'react';
import './imgList.scss';

const MENU_ITEMS = [
  { id: 1, label: 'ALL' },
  { id: 2, label: 'Web Design' },
  { id: 3, label: 'Development' },
  { id: 4, label: 'Marketing' },
];

const PORTFOLIO_ITEMS = [
  { id: 1, src: './images/sample01.jpg', alt: 'Web Design', href: '#', category: 'web' },
  { id: 2, src: './images/sample02.jpg', alt: 'Development', href: '#', category: 'de' },
  { id: 3, src: './images/sample03.jpg', alt: 'Development', href: '#', category: 'de' },
  { id: 4, src: './images/sample04.jpg', alt: 'Web Design', href: '#', category: 'web' },
  { id: 5, src: './images/sample05.jpg', alt: 'Marketing', href: '#', category: 'ma' },
  { id: 6, src: './images/sample06.jpg', alt: 'Web Design', href: '#', category: 'web' },
  { id: 7, src: './images/sample07.jpg', alt: 'Web Design', href: '#', category: 'web' },
  { id: 8, src: './images/sample08.jpg', alt: 'Development', href: '#', category: 'de' },
  { id: 9, src: './images/sample09.jpg', alt: 'Marketing', href: '#', category: 'ma' },
];

const FilterButton = memo(({ label, isActive, onClick }) => (
  <button className={isActive ? 'active' : ''} onClick={() => onClick(label)}>
    {label}
  </button>
));

const PortfolioCard = ({ item }) => (
  <section className={item.category} key={item.id}>
    <img src={item.src} alt={item.alt} />
    <div>
      <h4>{item.alt}</h4>
      <a href={item.href} className="material-symbols-outlined">favorite</a>
      <a href={item.href} className="material-symbols-outlined">search</a>
    </div>
  </section>
);

function ImgList() {
  const [activeCategory, setActiveCategory] = useState('ALL');

  const filteredItems =
    activeCategory === 'ALL'
      ? PORTFOLIO_ITEMS
      : PORTFOLIO_ITEMS.filter(item => item.alt === activeCategory);

  return (
    <div>
      <section id="layout">
        <h1>My Portfolio</h1>
        <p>I love what I do. I take great pride in what I do.</p>
        <hr />

        <nav>
          {MENU_ITEMS.map(menu => (
            <FilterButton
              key={menu.id}
              label={menu.label}
              isActive={menu.label === activeCategory}
              onClick={setActiveCategory}
            />
          ))}
        </nav>

        <div id="samples">
          {filteredItems.map(item => (
            <PortfolioCard key={item.id} item={item} />
          ))}
        </div>
      </section>
    </div>
  );
}

export default ImgList;